﻿sc\_toolbox.plot.genotype\_vs\_genotype\_umaps
==============================================

.. currentmodule:: sc_toolbox.plot

.. autofunction:: genotype_vs_genotype_umaps