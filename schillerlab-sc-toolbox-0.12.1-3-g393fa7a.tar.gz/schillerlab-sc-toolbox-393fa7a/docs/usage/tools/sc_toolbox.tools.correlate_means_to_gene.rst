﻿sc\_toolbox.tools.correlate\_means\_to\_gene
============================================

.. currentmodule:: sc_toolbox.tools

.. autofunction:: correlate_means_to_gene