﻿sc\_toolbox.tools.tidy\_de\_table
=================================

.. currentmodule:: sc_toolbox.tools

.. autofunction:: tidy_de_table