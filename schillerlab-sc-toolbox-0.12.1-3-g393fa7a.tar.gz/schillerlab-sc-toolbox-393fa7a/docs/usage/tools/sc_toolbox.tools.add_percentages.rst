﻿sc\_toolbox.tools.add\_percentages
==================================

.. currentmodule:: sc_toolbox.tools

.. autofunction:: add_percentages