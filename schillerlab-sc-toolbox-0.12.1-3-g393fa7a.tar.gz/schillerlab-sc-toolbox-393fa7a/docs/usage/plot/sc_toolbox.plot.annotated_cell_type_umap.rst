﻿sc\_toolbox.plot.annotated\_cell\_type\_umap
============================================

.. currentmodule:: sc_toolbox.plot

.. autofunction:: annotated_cell_type_umap