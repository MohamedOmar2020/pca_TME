﻿sc\_toolbox.tools.generate\_count\_object
=========================================

.. currentmodule:: sc_toolbox.tools

.. autofunction:: generate_count_object