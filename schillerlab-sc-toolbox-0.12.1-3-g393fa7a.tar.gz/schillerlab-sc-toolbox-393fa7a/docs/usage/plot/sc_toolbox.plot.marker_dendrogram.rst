﻿sc\_toolbox.plot.marker\_dendrogram
===================================

.. currentmodule:: sc_toolbox.plot

.. autofunction:: marker_dendrogram