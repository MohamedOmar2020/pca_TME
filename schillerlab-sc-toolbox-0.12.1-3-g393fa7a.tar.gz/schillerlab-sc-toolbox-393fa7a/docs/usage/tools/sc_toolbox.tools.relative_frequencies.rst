﻿sc\_toolbox.tools.relative\_frequencies
=======================================

.. currentmodule:: sc_toolbox.tools

.. autofunction:: relative_frequencies