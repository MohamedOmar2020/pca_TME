﻿sc\_toolbox.plot.relative\_frequencies\_boxplots
================================================

.. currentmodule:: sc_toolbox.plot

.. autofunction:: relative_frequencies_boxplots