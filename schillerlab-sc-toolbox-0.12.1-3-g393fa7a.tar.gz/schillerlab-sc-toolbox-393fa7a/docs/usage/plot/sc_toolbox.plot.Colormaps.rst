﻿sc\_toolbox.plot.Colormaps
==========================

.. currentmodule:: sc_toolbox.plot

.. add toctree option to make autodoc generate the pages

.. autoclass:: Colormaps



Attributes table
~~~~~~~~~~~~~~~~~~

.. autosummary::

    ~sc_toolbox.plot.Colormaps.grey_red
    ~sc_toolbox.plot.Colormaps.grey_green
    ~sc_toolbox.plot.Colormaps.grey_yellow
    ~sc_toolbox.plot.Colormaps.grey_violet
    ~sc_toolbox.plot.Colormaps.grey_blue









Attributes
~~~~~~~~~~~


grey_red
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. autoattribute:: Colormaps.grey_red
grey_green
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. autoattribute:: Colormaps.grey_green
grey_yellow
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. autoattribute:: Colormaps.grey_yellow
grey_violet
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. autoattribute:: Colormaps.grey_violet
grey_blue
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. autoattribute:: Colormaps.grey_blue






