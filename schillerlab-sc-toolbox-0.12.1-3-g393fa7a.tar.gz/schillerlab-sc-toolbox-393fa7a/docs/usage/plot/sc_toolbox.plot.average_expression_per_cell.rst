﻿sc\_toolbox.plot.average\_expression\_per\_cell
===============================================

.. currentmodule:: sc_toolbox.plot

.. autofunction:: average_expression_per_cell