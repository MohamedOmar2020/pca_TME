﻿sc\_toolbox.plot.gene\_boxplot
==============================

.. currentmodule:: sc_toolbox.plot

.. autofunction:: gene_boxplot