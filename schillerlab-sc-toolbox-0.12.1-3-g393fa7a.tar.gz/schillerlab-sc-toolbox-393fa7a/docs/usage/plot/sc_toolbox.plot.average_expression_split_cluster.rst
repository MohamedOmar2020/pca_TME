﻿sc\_toolbox.plot.average\_expression\_split\_cluster
====================================================

.. currentmodule:: sc_toolbox.plot

.. autofunction:: average_expression_split_cluster