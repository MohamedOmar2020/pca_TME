﻿sc\_toolbox.plot.volcano\_plot
==============================

.. currentmodule:: sc_toolbox.plot

.. autofunction:: volcano_plot