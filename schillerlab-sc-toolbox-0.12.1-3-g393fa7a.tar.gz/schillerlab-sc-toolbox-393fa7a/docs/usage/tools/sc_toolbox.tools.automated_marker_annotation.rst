﻿sc\_toolbox.tools.automated\_marker\_annotation
===============================================

.. currentmodule:: sc_toolbox.tools

.. autofunction:: automated_marker_annotation