﻿sc\_toolbox.plot.relative\_frequencies\_lineplot
================================================

.. currentmodule:: sc_toolbox.plot

.. autofunction:: relative_frequencies_lineplot