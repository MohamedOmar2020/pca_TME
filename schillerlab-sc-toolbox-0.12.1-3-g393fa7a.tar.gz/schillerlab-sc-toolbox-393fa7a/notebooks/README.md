# SC-Toolbox Notebook Collection

The notebooks contained in this folder are supposed to demonstrate example usages of all sc-toolbox provided functions.
They may not necessarily be reproducible yet since they were created with datasets which are not easily publicly available.
However, we are planning to replace these notebooks with applications on datasets like the PBMC data.
Contributions in this area are very welcome.
