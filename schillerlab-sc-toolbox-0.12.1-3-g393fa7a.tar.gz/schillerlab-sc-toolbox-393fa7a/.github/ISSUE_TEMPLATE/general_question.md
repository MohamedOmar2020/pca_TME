---
name: General question
about: Ask a question about anything related to this project
title: "Question"
labels: "question"
assignees: ""
---

**Question**

<!-- Please ask your question here. It can be about the usage of this project, the internals, the implementation or whatever interests you.
Please use the BUG template for bugs and the FEATURE REQUEST template for feature requests. -->
