﻿sc\_toolbox.plot.custom\_plot\_size
===================================

.. currentmodule:: sc_toolbox.plot

.. autofunction:: custom_plot_size