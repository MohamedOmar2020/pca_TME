"""Test suite for the sc_toolbox package."""
