﻿sc\_toolbox.tools.remove\_outliers
==================================

.. currentmodule:: sc_toolbox.tools

.. autofunction:: remove_outliers