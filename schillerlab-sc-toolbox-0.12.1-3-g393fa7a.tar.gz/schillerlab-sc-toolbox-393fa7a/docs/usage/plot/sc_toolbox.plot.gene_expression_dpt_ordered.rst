﻿sc\_toolbox.plot.gene\_expression\_dpt\_ordered
===============================================

.. currentmodule:: sc_toolbox.plot

.. autofunction:: gene_expression_dpt_ordered