﻿sc\_toolbox.plot.split\_boxplot
===============================

.. currentmodule:: sc_toolbox.plot

.. autofunction:: split_boxplot