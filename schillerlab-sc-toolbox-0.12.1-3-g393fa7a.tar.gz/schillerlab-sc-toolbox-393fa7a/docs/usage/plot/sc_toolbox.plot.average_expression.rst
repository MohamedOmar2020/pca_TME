﻿sc\_toolbox.plot.average\_expression
====================================

.. currentmodule:: sc_toolbox.plot

.. autofunction:: average_expression