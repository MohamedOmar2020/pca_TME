﻿sc\_toolbox.tools.extended\_marker\_table
=========================================

.. currentmodule:: sc_toolbox.tools

.. autofunction:: extended_marker_table