﻿sc\_toolbox.tools.de\_res\_to\_anndata
======================================

.. currentmodule:: sc_toolbox.tools

.. autofunction:: de_res_to_anndata